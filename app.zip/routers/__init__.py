from .auth_route import auth_router
from .order_route import order_router
from .stadium_route import stadium_router

__all__ = ["auth_router", "order_router", "stadium_router"]
