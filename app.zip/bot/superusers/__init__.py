async def super_init():
    from . import admin_menu
    from . import backs
    from . import start
