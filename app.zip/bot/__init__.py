from .loader import bot, bot_meta
