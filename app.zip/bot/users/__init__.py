async def user_init():
    from . import start
    from . import auth
    from . import booking
    from . import add_stadiums
    from . import manage_stadiums
    from . import my_orders
    from . import settings
    from . import help
    from . import backs
